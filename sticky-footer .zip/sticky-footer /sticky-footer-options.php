<?php 
     
    if($_POST['oscimp_hidden'] == 'Y') {
        //Form data sent
        $sticky_footer_height = $_POST['sticky_footer_height'];
        update_option('sticky_footer_height', $sticky_footer_height);
 
        $sticky_footer_width = $_POST['sticky_footer_width'];
        update_option('sticky_footer_width', $sticky_footer_width);
        
        $sticky_footer_background = $_POST['sticky_footer_background'];
        update_option('sticky_footer_background', $sticky_footer_background);
        
        $sticky_footer_color = $_POST['sticky_footer_color'];
        update_option('sticky_footer_color', $sticky_footer_color);
        
        $sticky_footer_opacity = $_POST['sticky_footer_opacity'];
        update_option('sticky_footer_opacity', $sticky_footer_opacity);
        
        $sticky_footer_text = $_POST['sticky_footer_text'];
        update_option('sticky_footer_text', $sticky_footer_text);
        
        $sticky_footer_font_size = $_POST['sticky_footer_font_size'];
        update_option('sticky_footer_font_size', $sticky_footer_font_size);
        
        
        ?>
        <div class="updated"><p><strong><?php _e('Options saved.' ); ?></strong></p></div>
        <?php
    } else {
        //Normal page display
        $sticky_footer_height = get_option('sticky_footer_height');
        $sticky_footer_width = get_option('sticky_footer_width');
        $sticky_footer_background = get_option('sticky_footer_background');
        $sticky_footer_color = get_option('sticky_footer_color');
        $sticky_footer_opacity = get_option('sticky_footer_opacity');
        $sticky_footer_text = get_option('sticky_footer_text');
        $sticky_footer_font_size = get_option('sticky_footer_font_size');
    }
?>

<div class="wrap"> 
        <h1>Sticky Footer Options</h1>    
        <p>Here you can manage the sticky footer style text opacity ,etc</p>
        <form name="oscimp_form" method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
        <input type="hidden" name="oscimp_hidden" value="Y">
            <table class="WP_List_Table fixed" cellspacing="0" width="40%">
    	   <tbody>
        	<tr>
        	    <td>
        			Width of sticky footer  
        	    </td>
        	    <td>
        	        <input type="number" name="sticky_footer_width" value="<?php echo $sticky_footer_width; ?>" size="20" required> %
        	    </td>
        	</tr>
        	<tr>
        	    <td >
        		    Height of sticky footer  
                </td>
                <td >
                  <input type="number" name="sticky_footer_height" value="<?php echo $sticky_footer_height; ?>" size="20" required> px
                </td>
            </tr>
            <tr>
        	    <td >
        		    Background color (HTML color code) 
                </td>
                <td >
                  <input type="text" name="sticky_footer_background" value="<?php echo $sticky_footer_background; ?>" size="20" required> 
                </td>
            </tr>
             <tr>
        	    <td >
        		    Font color (HTML color code)
                </td>
                <td >
                  <input type="text" name="sticky_footer_color" value="<?php echo $sticky_footer_color; ?>" size="20" required> 
                </td>
            </tr>
             <tr>
        	    <td >
        		    Opacity (Enter value between 0 to 10)
                </td>
                <td >
                  <input type="number" name="sticky_footer_opacity" value="<?php echo $sticky_footer_opacity; ?>" size="20" required> 
                </td>
            </tr>
             <tr>
        	    <td >
        		    Text  
                </td>
                <td >
                  <input type="text" name="sticky_footer_text" value="<?php echo $sticky_footer_text; ?>" size="20"> 
                </td>
            </tr>
             <tr>
        	    <td >
        		    Font Size  
                </td>
                <td >
                  <input type="number" name="sticky_footer_font_size" value="<?php echo $sticky_footer_font_size; ?>" size="20" required> 
                </td>
            </tr>
            
            
            <tr>   
                <td >      
        			<p class="submit">
        				<input type="submit" name="Submit" value="<?php _e('Update Options', 'oscimp_trdom' ) ?>" />
        			</p>
        		</td>
        		<td>
        		</td>
          </tr>
         </tbody>
        </table>
    </form>
</div>
