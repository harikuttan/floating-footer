<?php
/*
Plugin Name: Sticky footer 
Plugin URI: http://cabotsolutions.com/
Description: Just another contact sticky footer plugin that adds a floating footer at the botton of the screen
Author: Hareendranath.P	
Text Domain: Sticky Footer 
Version: 1.0.0
*/
?>

<?php 
//Original article 

function stickyFooter(){
   $sticky_footer_height = get_option('sticky_footer_height');
   $sticky_footer_width = get_option('sticky_footer_width');
   $sticky_footer_background = get_option('sticky_footer_background');
   $sticky_footer_color = get_option('sticky_footer_color');
   $sticky_footer_opacity = get_option('sticky_footer_opacity');
   $sticky_footer_text = get_option('sticky_footer_text');
   $sticky_footer_font_size = get_option('sticky_footer_font_size');
   echo '<div id="footer">'.$sticky_footer_text.'</div>';
   echo '<style>
          #footer{
	         padding: 16px 0 0 32px;
		 font-size: '.$sticky_footer_font_size.'px;
	         width:'.$sticky_footer_width.'%;
	         height:'.$sticky_footer_height.'px;
	         background: '.$sticky_footer_background.';
	         position: fixed;
	         opacity:'.$sticky_footer_opacity.';
	         bottom: 0;
	         color:'.$sticky_footer_color.';
	         z-index:20;
	         text-align: center;
                 vertical-align: middle;
                 line-height:'.$sticky_footer_height.'px;
	        }
         </style>';
}
?>
<?php 
    
    /** Action scripts for triggering hooks **/ 
	add_action('wp_footer','stickyFooter');

?>

<?php 
/** Admin side for adding text and options to sticky footer **/ 
/** Action for registering menu */
add_action( 'admin_menu', 'sticky_footer_menu');

/** Function for registering admin menu for sticky footer */
function sticky_footer_menu() {
	add_options_page( 'Sticky Footer Options', 'Sticky Footer', 'manage_options', 'sticky-footer-menu-options', 'sticky_footer_options' );
}

/** Function for creating menu options page for sticky footer **/
function sticky_footer_options(){
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	include('sticky-footer-options.php');
}
?>








